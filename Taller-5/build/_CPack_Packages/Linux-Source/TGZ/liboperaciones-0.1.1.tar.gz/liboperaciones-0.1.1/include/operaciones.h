#ifndef OPERACIONES
#define OPERACIONES
#define TOL 10e-3 // tolerancia
#define PI 3.141592654  //Se define PI
#include <stdlib.h>

double suma(double a, double b);
double resta(double a, double b);
double mul(double a, double b);
double divi(double a, double b);
double raiz(double a);
double coseno(double a);

#endif